# JioFi 2 M2S Permanent Network Unlock Package

Permanent SIM unlock package and fastboot flashing scripts for **JioFi 2 M2S** (Qualcomm Snapdragon MDM9607).

This package fixes the issue where non-Jio SIM cards (Vi, Airtel, BSNL) stop working or display **"Detached" / Red LED** after a device reboot.

---

## Package Contents

* `aboot_jiofi2_m2s.img` — Unlocked application bootloader (PEG_M2S_B04 base)
* `modem_jiofi2_m2s.img` — Patched Qualcomm modem firmware with SimLock bypass
* `flash_unlock_permanent.bat` — 1-click Windows fastboot flashing script
* `flash_unlock_permanent.sh` — Linux / macOS fastboot flashing script
* `README.md` — This documentation

---

## Instructions

### 1. Boot into Fastboot Mode
1. Power off the JioFi M2S completely.
2. Hold **WPS button + Power button** simultaneously for 3 to 5 seconds until the LEDs stay lit.
3. Connect the JioFi to your PC using a micro-USB data cable.

### 2. Flash
* **On Windows:** Double-click `flash_unlock_permanent.bat`.
* **On Linux / macOS:** Run `chmod +x flash_unlock_permanent.sh && ./flash_unlock_permanent.sh`.

### 3. Configure APN (Must do once)
1. Connect to the JioFi Wi-Fi and open `http://jiofi.local.html` (or `http://192.168.225.1`).
2. Log in (`administrator` / `administrator`).
3. Go to **Network** -> **Profile Management**:
   - Change mode to **Manual**.
   - Add new profile:
     - **Vi:** `portalnmms` (or `www`)
     - **Airtel:** `airtelgprs.com`
     - **BSNL:** `bsnlnet`
   - Set as **Default Profile**.
4. Enable **Data Roaming** under Network Settings.

---

## Credits & Attribution
* **abhimortal6 (ab_hi_j on XDA):** For reverse-engineering the modem firmware and creating the `aboot` and `modem` patch images.
* Fastboot automation scripts and reboot-persistence tutorial compiled for the community.
